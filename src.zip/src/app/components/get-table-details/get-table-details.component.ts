import { Component, OnInit } from '@angular/core';
import { RestaurantService } from '../../services/restaurant.service';
import { Router } from '@angular/router';
import { ITableDetails } from '../../interfaces/TableDetails';


@Component({
  selector: 'app-get-table-details',
  templateUrl: './get-table-details.component.html',
  styleUrls: ['./get-table-details.component.css']
})
export class GetTableDetailsComponent implements OnInit {
  tableDetails: ITableDetails[];
  errorMsg: string;
  showMsgDiv: boolean = false;
  status: boolean;
  constructor(private _restaurant_service: RestaurantService, private router: Router) { }

  ngOnInit() {
           //To do implement necessary logic
    this.getTable();
  }

  getTable() {
       //To do implement necessary logic
    this._restaurant_service.getTableDetails().subscribe(response => {
      this.tableDetails = response;
      this.showMsgDiv = false;
    },
      responseProductError => {
        this.tableDetails = null;
        this.errorMsg = responseProductError;
        //console.log(this.errorMsg);
      });
    () => console.log("Table Detail Successfully Fetched");

  }

  updateTableIncharge(tableObj: ITableDetails) {
           //To do implement necessary logic
    this.router.navigate(['/updatetableInchargeId', tableObj.tableId, tableObj.type, tableObj.accommodation, tableObj.tableInchargeId]);
  
  }

 }


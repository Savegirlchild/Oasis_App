import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetTableDetailsComponent } from './get-table-details.component';

describe('GetTableDetailsComponent', () => {
  let component: GetTableDetailsComponent;
  let fixture: ComponentFixture<GetTableDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetTableDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetTableDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

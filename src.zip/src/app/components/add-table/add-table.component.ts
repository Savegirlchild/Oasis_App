import { Component, OnInit, ViewChild } from '@angular/core';
import {NgForm} from '@angular/forms';
import { RestaurantService } from '../../services/restaurant.service'
import { HttpClient } from '@angular/common/http';
import { ITableDetails } from '../../interfaces/TableDetails'


@Component({
  selector: 'app-add-table',
  templateUrl: './add-table.component.html',
  styleUrls: ['./add-table.component.css']
})
export class AddTableComponent implements OnInit {
  @ViewChild(NgForm) ngForm: NgForm;
  message: boolean;
  errorMsg: string;
  showMsgDiv: boolean = false;
  status: boolean;
  constructor(private restaurantservice: RestaurantService) { }

  ngOnInit() {

  }
  addTable(tableId: string, type: string, accommodation: number, tableInchargeId: string) {
   //To do implement necessary logic
    this.restaurantservice.addTableDetails(tableId, type, accommodation, tableInchargeId).subscribe(
      response => {
        this.message = response;
        if (this.message) {
          alert("Succcessfully added");
        }
        else {
          alert("Sorry, something went error");
        }
      },
      error => {
        this.errorMsg = error;
        alert("something went error.Please try after some time");
      },
      () => { console.log("AddTable successfully excuted"); }
    );
  }

  

}

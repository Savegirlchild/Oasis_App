import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateTableInchargeIdComponent } from './update-table-incharge-id.component';

describe('UpdateTableInchargeIdComponent', () => {
  let component: UpdateTableInchargeIdComponent;
  let fixture: ComponentFixture<UpdateTableInchargeIdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateTableInchargeIdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateTableInchargeIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

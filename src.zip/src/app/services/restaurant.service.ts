import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ITableDetails } from '../interfaces/TableDetails';
import { ICustodian } from '../interfaces/CustodianDetails';
import { ICustomer } from '../interfaces/Customer';

@Injectable({
  providedIn: 'root'
})
export class RestaurantService {
  custodianId: string
  constructor(private _http: HttpClient) { }

  getTableDetails(): Observable<ITableDetails[]> {
    //To do implement necessary logic
    let tempVar = this._http.get<ITableDetails[]>('http://localhost:59284/api/Restaurant/GetTableDetails').pipe(catchError(this.errorHandler));
    return tempVar;
  }

  getCustomerDetails(): Observable<ICustomer[]> {
    //To do implement necessary logic
    let tempVar = this._http.get<ICustomer[]>('http://localhost:59284/api/Restaurant/GetCustomerDetails').pipe(catchError(this.errorHandler));
    return tempVar;
  }

  addTableDetails(tableId: string, type: string, accommodation: number, tableInchargeId: string): Observable<boolean> {
    //To do implement necessary logic
    var details: ITableDetails;
    details = { tableId: tableId, type: type, accommodation: accommodation, tableInchargeId: tableInchargeId};
    return this._http.post<boolean>('http://localhost:59284/api/Restaurant/InsertTable', details).pipe(catchError(this.errorHandler));
    
  }
  updateTableIncharge(tableId: string, type: string, accommodation: number, tableInchargeId: string): Observable<boolean> {
    //To do implement necessary logic
    var updatetable: ITableDetails;
    updatetable = { tableId: tableId, type: type, accommodation: accommodation, tableInchargeId: tableInchargeId };
    return this._http.put<boolean>('http://localhost:59284/api/Restaurant/UpdateTableInchargeId', updatetable).pipe(catchError(this.errorHandler));
  }

  removeCustomer(bookingId: number, customerName: string, bookingdate: Date, contact: number, tableNumber: string, duration: number, totalSeats: number): Observable<boolean> {
    //To do implement necessary logic
    var customer: ICustomer;
    customer = { bookingId: bookingId, customerName: customerName, bookingDate: bookingdate, contact: contact, tableNumber: tableNumber, duration: duration, totalSeats: totalSeats};
    let httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }), body: customer };
    return this._http.delete<boolean>('http://localhost:59284/api/Restaurant/DeleteCustomer', httpOptions).pipe(catchError(this.errorHandler));
  }

  errorHandler(error: HttpErrorResponse) {
    //To do implement necessary logic
    console.error(error);
    return throwError(error.message || "Server Error");
  }
}

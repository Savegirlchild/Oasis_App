﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace OasisDataAccessLayer.Models
{
    public partial class RestaurantDBContext : DbContext
    {
        public RestaurantDBContext()
        {
        }

        public RestaurantDBContext(DbContextOptions<RestaurantDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<CustodianDetail> CustodianDetail { get; set; }
        public virtual DbSet<CustomerDetail> CustomerDetail { get; set; }
        public virtual DbSet<TableDetail> TableDetail { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source =(localdb)\\mssqllocaldb;Initial Catalog=RestaurantDB;Integrated Security=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CustodianDetail>(entity =>
            {
                entity.HasKey(e => e.CustodianId);

                entity.Property(e => e.CustodianId)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.CustodianName)
                    .HasMaxLength(15)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CustomerDetail>(entity =>
            {
                entity.HasKey(e => e.BookingId);

                entity.Property(e => e.BookingDate).HasColumnType("date");

                entity.Property(e => e.CustomerName)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.TableNumber)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.HasOne(d => d.TableNumberNavigation)
                    .WithMany(p => p.CustomerDetail)
                    .HasForeignKey(d => d.TableNumber)
                    .HasConstraintName("FK__CustomerD__Table__2E1BDC42");
            });

            modelBuilder.Entity<TableDetail>(entity =>
            {
                entity.HasKey(e => e.TableId);

                entity.Property(e => e.TableId)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.TableInchargeId)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Type)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.HasOne(d => d.TableIncharge)
                    .WithMany(p => p.TableDetail)
                    .HasForeignKey(d => d.TableInchargeId)
                    .HasConstraintName("FK__TableDeta__Table__2A4B4B5E");
            });
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OasisDataAccessLayer;
using OasisDataAccessLayer.Models;


namespace OasisWebApplication.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class RestaurantController : ControllerBase
    {
        RestaurantRepository repository = new RestaurantRepository();

        #region GetTableDetails
        [HttpGet]
        public JsonResult GetTableDetails()
        {           
            try
            {
                var TableList = repository.ShowTableDetails();
                var tableList = new List<Models.TableDetails>();
                if (TableList.Any())
                {
                    foreach (var item in TableList)
                    {
                        tableList.Add(new Models.TableDetails
                        {
                            Accommodation = item.Accommodation,
                            Type = item.Type,
                            TableId = item.TableId,
                            TableInchargeId = item.TableInchargeId
                        });
                    }
                }
                return new JsonResult(tableList);
            }
            catch
            {
                return null;
            }
            //return Json(tableList);
        }
        #endregion
        
        #region GetCustomerDetails
        [HttpGet]
        public JsonResult GetCustomerDetails()
        {

            try
            {
                var CustomerList = repository.GetCustomerDetails();
                var custList = new List<Models.CustomerDetails>();
                if (CustomerList.Any())
                {
                    foreach (var item in CustomerList)
                    {
                        custList.Add(new Models.CustomerDetails
                        {
                            BookingId = item.BookingId,
                            BookingDate = item.BookingDate,
                            TableNumber = item.TableNumber,
                            TotalSeats = item.TotalSeats,
                            Contact = item.Contact,
                            Duration = item.Duration,
                            CustomerName = item.CustomerName
                        });
                    }
                }
                return new JsonResult(custList);
            }
            catch
            {
                return null;
            }
            //return Json(tableList);
        }
        #endregion
        #region InsertTable
        [HttpPost]
        public bool InsertTable(Models.TableDetails TObj)
        {
            bool status = true;
            try
            {
                TableDetail TObj1 = new TableDetail();
                TObj1.TableId = TObj.TableId;
                TObj1.Type = TObj.Type;
                TObj1.Accommodation = TObj.Accommodation;
                TObj1.TableInchargeId = TObj.TableInchargeId;

                status = repository.AddTable(TObj1);
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }
        #endregion

        #region UpdateTableInchargeId
        [HttpPut]

        public bool UpdateTableInchargeId(Models.TableDetails Tobj)
        {
            bool status = true;
            try
            {
                TableDetail TObj1 = new TableDetail();
                TObj1.TableId = Tobj.TableId;
                TObj1.Type = Tobj.Type;
                TObj1.Accommodation = Tobj.Accommodation;
                TObj1.TableInchargeId = Tobj.TableInchargeId;

                status = repository.UpdateInchargeId(TObj1);
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }
        #endregion
        #region DeleteShow
        [HttpDelete]
        public bool DeleteCustomer(int custId)
        {
            var status = false;
            try
            {
                status = repository.RemoveCustomerDetails(custId);
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }
        #endregion

    }
}
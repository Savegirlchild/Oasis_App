﻿using System;
using System.Collections.Generic;

namespace OasisWebApplication.Models
{
    public partial class CustomerDetails
    {
        public long BookingId { get; set; }
        public DateTime? BookingDate { get; set; }
        public string TableNumber { get; set; }
        public string CustomerName { get; set; }
        public long? Contact { get; set; }
        public int? Duration { get; set; }
        public int? TotalSeats { get; set; }

        
    }
}
